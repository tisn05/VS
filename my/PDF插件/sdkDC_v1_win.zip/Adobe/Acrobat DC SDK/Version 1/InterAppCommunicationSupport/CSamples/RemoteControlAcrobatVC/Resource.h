//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by RemoteControlAcrobat.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_REMOTECONTROLACROBAT        102
#define IDR_MAINFRAME                   128
#define IDR_REMOTETYPE                  129
#define IDD_DIALOG1                     130
#define IDD_DIALOG2                     131
#define IDC_EDIT_WORD                   1000
#define IDC_STATIC_FILENAME             1001
#define IDC_STATIC_LABEL                1002
#define IDC_EDIT_NUMBER                 1003
#define ID_ACROBAT_APP_SHOW             32776
#define ID_ACROBAT_APP_HIDE             32777
#define ID_ACROBAT_AVDOC_OPEN           32782
#define ID_ACROBAT_AVDOC_PRINT          32784
#define ID_ACROBAT_AVDOC_FINDTEXT       32786
#define ID_ACROBAT_AVPAGEVIEW_PAGENUMBER 32787
#define ID_ACROBAT_AVPAGEVIEW_GOFORWARD 32788
#define ID_ACROBAT_AVPAGEVIEW_GOBACK    32789
#define ID_ACROBAT_LAUNCH               32791
#define ID_ACROBAT_QUIT                 32792
#define ID_ACROBAT_AVDOC_CLOSE          32794
#define ID_ACROBAT_AVPAGEVIEW_GOTOPAGE  32795

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32796
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
